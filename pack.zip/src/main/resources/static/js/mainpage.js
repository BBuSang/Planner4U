// 생성버튼 클릭 후 방생성 창 띄우기
const selected = document.querySelector(".create_box");
function movePage (){
    location.href="/app/createRoom";
}
