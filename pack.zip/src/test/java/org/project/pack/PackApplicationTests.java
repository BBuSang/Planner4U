package org.project.pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackApplicationTests {

	@Test
	void contextLoads() {
	}

}
